## Regenerating the graph_vis_main.dart.js{.map} files

To regenerate these files, you should use the custom build script at
`tool/build.dart`. This supports all the normal build_runner commands.
