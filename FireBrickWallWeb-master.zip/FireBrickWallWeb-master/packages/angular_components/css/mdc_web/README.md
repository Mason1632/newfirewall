The files located here are provided and maintained by the Google material team
also known as mdc-web. They are included here to make their use easier in
AngularDart applications. They are taken from a larger set of styles available
on [GitHub](https://github.com/material-components/material-components-web).
